﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMove : MonoBehaviour
{
    Vector3 start;
    Vector3 direction;
    int MaxJumps = 1;
    int jump_counter;
    // Start is called before the first frame update
    void Start()
    {
        start=new Vector3(0.0f,-0.2f,0.0f);
        Transform transform=gameObject.GetComponent<Transform>();
        jump_counter=MaxJumps;
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    private void FixedUpdate() {
        //print(transform.position.y);
        if (transform.position.y<-0.5f || Input.GetKeyDown(KeyCode.R))
        {
            transform.position=start;
        }
        if(Input.GetKey(KeyCode.Space) && jump_counter>0){
            gameObject.GetComponent<Rigidbody>().AddForce(new Vector3(0.0f,5.0f,0.0f)*100);
            jump_counter=0;
            print(jump_counter);
        }
        if(Input.GetAxisRaw("Horizontal")!=0||Input.GetAxisRaw("Vertical")!=0){
            direction=new Vector3(Input.GetAxisRaw("Horizontal"), 0, Input.GetAxisRaw("Vertical"));
            transform.rotation = Quaternion.LookRotation(direction);
            transform.position+=(direction*0.05f);
        }
        //if(transform.position.y<0.0f){
        //    jump_counter=MaxJumps;
        //}
    }

    private void OnCollisionEnter(Collision other) {
        //print(other.gameObject.name);
        if(other.gameObject.tag=="floor")
            jump_counter=MaxJumps;
            print(jump_counter);
    }
    /*private void OnTriggerEnter(Collider other) {
        jump_counter=MaxJumps;
    }*/
}
