# Troubleshooting

## Known issues

- Post-processing doesn't work on MacOS X 10.11.6 when running Metal in the editor due to a driver bug on this specific version of the OS.

For specific effect limitations / known issues please check the effect page.